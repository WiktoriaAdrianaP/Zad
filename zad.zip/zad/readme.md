W ramach tego zadania chcemy mieć możliwość dodawania nowych samochodów na stronie z listą modeli.
Aby to zrobić, musimy mieć możliwość przesłania danych do serwera.

Wstawiony został przycisk oraz pole tekstowe.
Dodatkowo dodany został Event Listener, który obsługuje wpisany tekst i przesyła go do serwera.
Zostaje obługa dodawania modelu w kontrolerze i implementacja dodawania w warstwie komunikacji z 'bazą'
czyli tam gdzie zapisujemy do pliku
